# bioSite
Website about Kenadii Williams, a makeup artist in Lexington

# CSD 340 Web Development with HTML and CSS
## Contributors
* Tatiyana Dean 
* Professor Sampson